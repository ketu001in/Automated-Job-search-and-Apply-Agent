/**
 * claude.js
 * Claude AI integration for:
 *   1. Assessing job compatibility against your profile
 *   2. Answering unknown Easy Apply form questions
 */

require('dotenv').config();
const Anthropic = require('@anthropic-ai/sdk');
const profile = require('./profile');

const client = new Anthropic({ apiKey: process.env.CLAUDE_API_KEY });

// ─── Job Compatibility Assessment ────────────────────────────────────────────

/**
 * Returns { compatible, score, reason, skip_reason }
 */
async function assessJobCompatibility(jobTitle, company, jobDescription) {
  try {
    const response = await client.messages.create({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 400,
      messages: [{
        role: 'user',
        content: `You are a career advisor. Assess whether this job is a good match for the candidate.

CANDIDATE PROFILE:
${profile.cvSummary}
Skills: ${profile.skills.join(', ')}
Total Experience: ${profile.yearsOfExperience} years
Current Title: ${profile.currentTitle}
Work Auth: India ✓  |  Open to Remote: ${profile.openToRemote}  |  Open to Hybrid: ${profile.openToHybrid}

JOB POSTING:
Title: ${jobTitle}
Company: ${company}
Description (first 2000 chars):
${(jobDescription || '').substring(0, 2000)}

Respond ONLY with valid JSON, no extra text:
{
  "compatible": true,
  "score": 8,
  "reason": "Strong match: cloud + PM background aligns with requirements",
  "skip_reason": ""
}`
      }]
    });

    const text = response.content[0].text.trim();
    // Strip any markdown code fences if present
    const clean = text.replace(/```json|```/g, '').trim();
    return JSON.parse(clean);
  } catch (err) {
    // Default to compatible if assessment fails, to avoid missing real jobs
    return {
      compatible: true,
      score: 5,
      reason: `Assessment unavailable (${err.message}); defaulting to compatible`,
      skip_reason: ''
    };
  }
}

// ─── Form Field Answer ────────────────────────────────────────────────────────

/**
 * Ask Claude to answer an arbitrary Easy Apply form question.
 * @param {string} question  - The label/question text
 * @param {string} fieldType - 'text' | 'number' | 'select' | 'radio' | 'checkbox' | 'textarea'
 * @param {string[]} options - For select/radio, the available options
 * @returns {string} Answer value
 */
async function getFormAnswer(question, fieldType, options = []) {
  // Fast-path: answer common fields locally without an API call
  const local = localAnswer(question, fieldType, options);
  if (local !== null) return local;

  try {
    const response = await client.messages.create({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 150,
      messages: [{
        role: 'user',
        content: `Answer this job application form question on behalf of the candidate below.

CANDIDATE:
Name: ${profile.name}
Email: ${profile.email}
Phone: ${profile.phone}
Experience: ${profile.yearsOfExperience} years
Current Title: ${profile.currentTitle} at ${profile.currentCompany}
Current CTC: ${profile.currentCTC} LPA
Expected CTC: ${profile.expectedCTC} LPA
Notice Period: ${profile.noticePeriod} days
Location: ${profile.location}
Work Auth (India): Yes
${profile.cvSummary}

QUESTION: "${question}"
FIELD TYPE: ${fieldType}
${options.length ? `OPTIONS (pick one exactly): ${options.join(' | ')}` : ''}

Reply with ONLY the answer value — no explanation, no punctuation around it.
For yes/no questions reply: Yes or No
For number fields reply: just the number
For select/radio reply: the exact option text from OPTIONS
For text/textarea reply: a concise professional answer`
      }]
    });

    return response.content[0].text.trim();
  } catch {
    return '';
  }
}

// ─── Local Fast-Path Answers ──────────────────────────────────────────────────

function localAnswer(question, fieldType, options) {
  const q = question.toLowerCase();

  if (matchesAny(q, ['total exp', 'years of exp', 'experience (years)', 'total years'])) {
    return String(profile.yearsOfExperience);
  }
  if (matchesAny(q, ['current ctc', 'current salary', 'present ctc', 'current package'])) {
    return String(profile.currentCTC);
  }
  if (matchesAny(q, ['expected ctc', 'expected salary', 'expected package', 'desired salary'])) {
    return String(profile.expectedCTC);
  }
  if (matchesAny(q, ['notice period', 'notice', 'joining time', 'how soon can you join'])) {
    return String(profile.noticePeriod);
  }
  if (matchesAny(q, ['phone', 'mobile number', 'contact number'])) {
    return profile.phone;
  }
  if (q.includes('email') && !q.includes('company')) {
    return profile.email;
  }
  if (matchesAny(q, ['first name'])) {
    return profile.name.split(' ')[0];
  }
  if (matchesAny(q, ['last name', 'surname'])) {
    return profile.name.split(' ').slice(1).join(' ');
  }
  if (matchesAny(q, ['full name', 'your name']) && !q.includes('company')) {
    return profile.name;
  }
  if (matchesAny(q, ['city', 'current city', 'current location'])) {
    return 'Bengaluru';
  }
  if (matchesAny(q, ['work authoriz', 'authorised to work', 'eligible to work', 'right to work'])) {
    return pickYesNo(options, true);
  }
  if (matchesAny(q, ['relocat'])) {
    return pickYesNo(options, profile.willingToRelocate);
  }
  if (matchesAny(q, ['remote', 'work from home'])) {
    return pickYesNo(options, profile.openToRemote);
  }
  if (matchesAny(q, ['us shift', 'night shift', 'us hours'])) {
    return pickYesNo(options, false);
  }
  if (matchesAny(q, ['agile', 'scrum', 'waterfall', 'project management methodology'])) {
    return pickYesNo(options, true);
  }
  if (matchesAny(q, ['cloud', 'gcp', 'aws', 'azure'])) {
    return pickYesNo(options, true);
  }
  if (matchesAny(q, ['bangalore', 'bengaluru', 'based in'])) {
    return pickYesNo(options, true);
  }
  if (matchesAny(q, ['virtual interview', 'video interview'])) {
    return pickYesNo(options, true);
  }
  if (matchesAny(q, ['english', 'language proficiency']) && options.length > 0) {
    // Pick native/bilingual if available
    const native = options.find(o => /native|bilingual/i.test(o));
    return native || options[0];
  }
  if (matchesAny(q, ['communication skill', 'interpersonal']) && options.length > 0) {
    return pickYesNo(options, true);
  }

  return null; // No local answer — use Claude
}

function matchesAny(str, keywords) {
  return keywords.some(k => str.includes(k));
}

function pickYesNo(options, value) {
  if (options.length === 0) return value ? 'Yes' : 'No';
  const yes = options.find(o => /^yes$/i.test(o.trim()));
  const no  = options.find(o => /^no$/i.test(o.trim()));
  if (value) return yes || options[0];
  return no || options[options.length - 1];
}

module.exports = { assessJobCompatibility, getFormAnswer };

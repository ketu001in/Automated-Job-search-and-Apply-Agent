/**
 * linkedin.js
 * Playwright-based LinkedIn automation:
 *   - Session management (cookies)
 *   - Job search (past 24 hours, Easy Apply filter)
 *   - Job compatibility assessment via Claude
 *   - Easy Apply multi-step modal handler
 */

require('dotenv').config();
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { assessJobCompatibility, getFormAnswer } = require('./claude');
const profile = require('./profile');

const COOKIES_FILE = path.join(__dirname, 'linkedin_session.json');
const HEADLESS = process.env.HEADLESS !== 'false';

// ─── Session ──────────────────────────────────────────────────────────────────

async function saveCookies(context) {
  const cookies = await context.cookies();
  fs.writeFileSync(COOKIES_FILE, JSON.stringify(cookies, null, 2));
}

async function loadCookies(context) {
  if (fs.existsSync(COOKIES_FILE)) {
    const cookies = JSON.parse(fs.readFileSync(COOKIES_FILE, 'utf8'));
    await context.addCookies(cookies);
    return true;
  }
  return false;
}

// ─── Main Agent Run ───────────────────────────────────────────────────────────

async function runLinkedInAgent(log) {
  const browser = await chromium.launch({
    headless: HEADLESS,
    slowMo: HEADLESS ? 0 : 300,
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  const context = await browser.newContext({
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    viewport: { width: 1280, height: 800 },
    locale: 'en-IN'
  });

  const hasCookies = await loadCookies(context);
  const page = await context.newPage();

  // ── Login ──────────────────────────────────────────────────────────────────
  try {
    await page.goto('https://www.linkedin.com/feed/', { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(3000);

    const isLoggedIn = await checkLoggedIn(page);

    if (!isLoggedIn) {
      if (process.env.LINKEDIN_EMAIL && process.env.LINKEDIN_PASSWORD) {
        log('🔐 Logging in with credentials...', 'info');
        await loginWithCredentials(page, log);
      } else if (!hasCookies) {
        log('⚠️  Not logged in. Open the browser window, log in manually to LinkedIn, then click "Save Session" on the dashboard.', 'warning');
        // Wait up to 5 min for manual login
        await page.waitForURL('**/feed/**', { timeout: 300000 });
      } else {
        log('❌ LinkedIn session expired. Re-run with LINKEDIN_EMAIL + LINKEDIN_PASSWORD, or save a fresh session.', 'error');
        await browser.close();
        return { applied: [], skipped: [], errors: ['Session expired'] };
      }
    }
  } catch (err) {
    log(`❌ Login error: ${err.message}`, 'error');
    await browser.close();
    return { applied: [], skipped: [], errors: [`Login failed: ${err.message}`] };
  }

  await saveCookies(context);
  log('✅ Logged in to LinkedIn', 'success');

  const applied = [];
  const skipped = [];
  const errors = [];
  const seenJobIds = new Set();

  // ── Search Loop ────────────────────────────────────────────────────────────
  for (const query of profile.searchQueries) {
    log(`\n🔍 Searching: "${query}"`, 'info');

    const url = `https://www.linkedin.com/jobs/search/?keywords=${encodeURIComponent(query)}&location=${encodeURIComponent(profile.location)}&f_TPR=r86400&f_LF=f_AL&sortBy=DD`;

    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await page.waitForTimeout(3000);
    } catch (err) {
      log(`⚠️  Could not load search page: ${err.message}`, 'warning');
      continue;
    }

    // Collect job IDs from the list panel
    const jobIds = await collectJobIds(page, log);
    log(`Found ${jobIds.length} jobs for "${query}"`, 'info');

    for (const jobId of jobIds) {
      if (seenJobIds.has(jobId)) {
        log(`⏭️  Duplicate job ID ${jobId}, skipping`, 'info');
        continue;
      }
      seenJobIds.add(jobId);

      try {
        // Load job detail
        await page.goto(`https://www.linkedin.com/jobs/view/${jobId}/`, { waitUntil: 'domcontentloaded', timeout: 30000 });
        await page.waitForTimeout(2000);

        const jobTitle = await getText(page, [
          '.job-details-jobs-unified-top-card__job-title h1',
          '.jobs-unified-top-card__job-title',
          'h1'
        ]);
        const company = await getText(page, [
          '.job-details-jobs-unified-top-card__company-name a',
          '.jobs-unified-top-card__company-name',
          '.topcard__org-name-link'
        ]);
        const description = await getText(page, [
          '.jobs-description-content__text',
          '.jobs-description',
          '#job-details'
        ]);

        // Already applied?
        const alreadyApplied = await page.$('.jobs-s-apply--applied, [aria-label*="Applied"], .artdeco-inline-feedback--success').catch(() => null);
        if (alreadyApplied) {
          log(`⏭️  Already applied: ${jobTitle} @ ${company}`, 'info');
          continue;
        }

        // Assess compatibility
        log(`🤖 Assessing: ${jobTitle} @ ${company}`, 'info');
        const assessment = await assessJobCompatibility(jobTitle, company, description);
        log(`   Score: ${assessment.score}/10 — ${assessment.reason}`, assessment.compatible ? 'info' : 'warning');

        if (!assessment.compatible || assessment.score < profile.minCompatibilityScore) {
          log(`❌ Skip: ${jobTitle} (${assessment.skip_reason || assessment.reason})`, 'warning');
          skipped.push({ jobId, title: jobTitle, company, score: assessment.score, reason: assessment.skip_reason || assessment.reason });
          continue;
        }

        // Find Easy Apply button
        const easyApplyBtn = await page.$([
          'button[aria-label*="Easy Apply"]',
          '.jobs-apply-button--top-card',
          'button.jobs-apply-button'
        ].join(', ')).catch(() => null);

        if (!easyApplyBtn) {
          log(`⚠️  No Easy Apply button for: ${jobTitle}`, 'warning');
          skipped.push({ jobId, title: jobTitle, company, score: assessment.score, reason: 'No Easy Apply button' });
          continue;
        }

        log(`🚀 Applying to: ${jobTitle} @ ${company}`, 'success');
        await easyApplyBtn.click();
        await page.waitForTimeout(2500);

        // Handle modal
        const submitted = await handleEasyApplyModal(page, log);

        if (submitted) {
          applied.push({
            jobId,
            title: jobTitle,
            company,
            score: assessment.score,
            reason: assessment.reason,
            url: `https://www.linkedin.com/jobs/view/${jobId}/`,
            appliedAt: new Date().toISOString()
          });
          log(`🎉 Applied: ${jobTitle} @ ${company}`, 'success');
        } else {
          errors.push(`Could not complete application for ${jobTitle} @ ${company}`);
          log(`⚠️  Could not complete application for ${jobTitle}`, 'warning');
          // Dismiss any open modal
          await page.keyboard.press('Escape').catch(() => {});
          await page.waitForTimeout(1000);
        }

        await page.waitForTimeout(2000);

      } catch (err) {
        log(`❌ Error on job ${jobId}: ${err.message}`, 'error');
        errors.push(`Job ${jobId}: ${err.message}`);
        await page.keyboard.press('Escape').catch(() => {});
        await page.waitForTimeout(1500);
      }
    }
  }

  await browser.close();
  return { applied, skipped, errors, timestamp: new Date().toISOString() };
}

// ─── Login With Credentials ───────────────────────────────────────────────────

async function loginWithCredentials(page, log) {
  await page.goto('https://www.linkedin.com/login', { waitUntil: 'domcontentloaded' });
  await page.fill('#username', process.env.LINKEDIN_EMAIL);
  await page.fill('#password', process.env.LINKEDIN_PASSWORD);
  await page.click('button[type="submit"]');
  await page.waitForTimeout(5000);

  if (page.url().includes('challenge') || page.url().includes('checkpoint')) {
    log('⚠️  LinkedIn security check required. Please complete it in the browser window.', 'warning');
    await page.waitForURL('**/feed/**', { timeout: 120000 });
  }
  log('✅ Logged in with credentials', 'success');
}

// ─── Collect Job IDs ──────────────────────────────────────────────────────────

async function collectJobIds(page, log) {
  const ids = new Set();
  let previousCount = 0;

  for (let scroll = 0; scroll < 5; scroll++) {
    // Grab job card links
    const links = await page.$$eval(
      'a.job-card-container__link, a[href*="/jobs/view/"]',
      els => els.map(el => {
        const m = el.href.match(/\/jobs\/view\/(\d+)/);
        return m ? m[1] : null;
      }).filter(Boolean)
    );
    links.forEach(id => ids.add(id));

    if (ids.size === previousCount) break;
    previousCount = ids.size;

    // Scroll job list panel
    await page.evaluate(() => {
      const panel = document.querySelector('.jobs-search-results-list, .scaffold-layout__list');
      if (panel) panel.scrollBy(0, 600);
    });
    await page.waitForTimeout(1500);
  }

  return [...ids];
}

// ─── Easy Apply Modal Handler ─────────────────────────────────────────────────

async function handleEasyApplyModal(page, log) {
  for (let step = 0; step < 25; step++) {
    await page.waitForTimeout(1500);

    // Check for success
    const bodyText = await page.evaluate(() => document.body.innerText);
    if (bodyText.includes('Your application was sent') || bodyText.includes('application was sent to')) {
      log('   ✅ Submission confirmed', 'success');
      // Dismiss post-apply dialog
      await page.click('button[aria-label="Dismiss"], button:has-text("Not now"), .artdeco-modal__dismiss').catch(() => {});
      return true;
    }

    // Modal still open?
    const modal = await page.$('.jobs-easy-apply-modal, [data-test-modal-id="easy-apply-modal"]');
    if (!modal) {
      // Modal closed without success — might have submitted
      await page.waitForTimeout(2000);
      const text = await page.evaluate(() => document.body.innerText);
      return text.includes('application was sent') || text.includes('Applied');
    }

    // Fill all visible form fields
    await fillVisibleFields(page, log);

    // Determine which button to click
    const submitBtn  = await page.$('button[aria-label="Submit application"]');
    const reviewBtn  = await page.$('button[aria-label="Review your application"], button[aria-label="Review"]');
    const nextBtn    = await page.$('button[aria-label="Continue to next step"]');
    const primaryBtn = await page.$('.jobs-easy-apply-modal .artdeco-button--primary');

    const btn = submitBtn || reviewBtn || nextBtn || primaryBtn;

    if (btn) {
      const label = await btn.evaluate(el => el.textContent.trim());
      log(`   ▶ Clicking: ${label}`, 'info');
      await btn.click();
    } else {
      log('   ⚠️  No actionable button found in modal', 'warning');
      return false;
    }

    await page.waitForTimeout(2000);
  }

  return false;
}

// ─── Form Field Filler ────────────────────────────────────────────────────────

async function fillVisibleFields(page, log) {
  // Upload resume if prompted (use the one already saved in LinkedIn)
  // LinkedIn usually pre-selects the saved resume — we just skip this

  // ── Text / Number inputs ──────────────────────────────────────────────────
  const inputs = await page.$$('.jobs-easy-apply-modal input[type="text"], .jobs-easy-apply-modal input[type="number"], .jobs-easy-apply-modal input[type="tel"]');

  for (const input of inputs) {
    try {
      const existing = await input.inputValue();
      if (existing && existing.trim() !== '') continue; // already filled

      const label = await getLabelFor(page, input);
      if (!label) continue;

      const answer = await getFormAnswer(label, 'text');
      if (!answer) continue;

      await input.fill(answer);
      log(`   Filled "${label}": ${answer}`, 'info');
    } catch { /* skip */ }
  }

  // ── Textareas ─────────────────────────────────────────────────────────────
  const textareas = await page.$$('.jobs-easy-apply-modal textarea');
  for (const ta of textareas) {
    try {
      const existing = await ta.inputValue();
      if (existing && existing.trim() !== '') continue;

      const label = await getLabelFor(page, ta);
      if (!label) continue;

      const answer = await getFormAnswer(label, 'textarea');
      if (answer) {
        await ta.fill(answer);
        log(`   Filled textarea "${label}"`, 'info');
      }
    } catch { /* skip */ }
  }

  // ── Selects ───────────────────────────────────────────────────────────────
  const selects = await page.$$('.jobs-easy-apply-modal select');
  for (const sel of selects) {
    try {
      const existing = await sel.inputValue();
      if (existing && existing !== '') continue;

      const label = await getLabelFor(page, sel);
      const options = await sel.$$eval('option', opts =>
        opts.map(o => o.textContent.trim()).filter(t => t && !/select an option/i.test(t))
      );
      if (!options.length) continue;

      const answer = await getFormAnswer(label || '', 'select', options);
      if (answer) {
        await sel.selectOption({ label: answer }).catch(async () => {
          // Fallback: select by value
          await sel.selectOption(options[0]);
        });
        log(`   Selected "${label}": ${answer}`, 'info');
      }
    } catch { /* skip */ }
  }

  // ── Custom LinkedIn dropdowns (div-based) ─────────────────────────────────
  const dropdownBtns = await page.$$('.jobs-easy-apply-modal [data-test-text-entity-list-form-component] button, .jobs-easy-apply-modal .fb-dash-form-element__element button[role="combobox"]');
  for (const btn of dropdownBtns) {
    try {
      const currentVal = await btn.textContent();
      if (currentVal && !/select/i.test(currentVal)) continue;

      const label = await getLabelFor(page, btn);
      await btn.click();
      await page.waitForTimeout(800);

      const optionEls = await page.$$('[role="option"], .jobs-easy-apply-modal li[role="option"]');
      if (!optionEls.length) continue;

      const options = await Promise.all(optionEls.map(el => el.textContent().then(t => t.trim())));
      const answer = await getFormAnswer(label || '', 'select', options.filter(Boolean));

      // Click matching option
      for (const el of optionEls) {
        const text = await el.textContent().then(t => t.trim());
        if (text === answer) {
          await el.click();
          log(`   Chose "${text}" in custom dropdown "${label}"`, 'info');
          break;
        }
      }
    } catch { /* skip */ }
  }

  // ── Radio buttons ─────────────────────────────────────────────────────────
  const radioGroups = await page.$$('.jobs-easy-apply-modal fieldset');
  for (const fieldset of radioGroups) {
    try {
      const anyChecked = await fieldset.$('input[type="radio"]:checked');
      if (anyChecked) continue;

      const legend = await fieldset.$eval('legend', el => el.textContent.trim()).catch(() => '');
      const radios = await fieldset.$$('input[type="radio"]');
      const radioLabels = await Promise.all(radios.map(async r => {
        const id = await r.getAttribute('id');
        return page.$eval(`label[for="${id}"]`, el => el.textContent.trim()).catch(() => '');
      }));

      const answer = await getFormAnswer(legend, 'radio', radioLabels.filter(Boolean));
      for (let i = 0; i < radioLabels.length; i++) {
        if (radioLabels[i] === answer) {
          await radios[i].click();
          log(`   Radio "${legend}": ${answer}`, 'info');
          break;
        }
      }
    } catch { /* skip */ }
  }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function getLabelFor(page, element) {
  return page.evaluate(el => {
    // Try for attribute on element
    const id = el.id || el.getAttribute('id');
    if (id) {
      const lbl = document.querySelector(`label[for="${id}"]`);
      if (lbl) return lbl.textContent.trim();
    }
    // Walk up to form element container
    const container = el.closest('.fb-form-element, .jobs-easy-apply-form-element, .fb-dash-form-element, .artdeco-form__group');
    if (container) {
      const lbl = container.querySelector('label, legend, h3, span.visually-hidden');
      if (lbl) return lbl.textContent.trim();
    }
    // Placeholder fallback
    return el.placeholder || el.getAttribute('aria-label') || '';
  }, element).catch(() => '');
}

async function checkLoggedIn(page) {
  return !page.url().includes('/login') &&
    !page.url().includes('/authwall') &&
    !page.url().includes('/uas/login') &&
    await page.$('nav.global-nav').catch(() => null) !== null;
}

async function getText(page, selectors) {
  for (const sel of selectors) {
    try {
      const el = await page.$(sel);
      if (el) return (await el.textContent()).trim();
    } catch { /* try next */ }
  }
  return '';
}

module.exports = { runLinkedInAgent };
